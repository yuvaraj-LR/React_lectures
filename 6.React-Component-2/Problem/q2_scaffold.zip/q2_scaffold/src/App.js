import "./styles.css";
import React from "react";

function App() {
  return (
    <div className="App">
      <h1>Reach me</h1>
      {/* Code here */}
    </div>
  );
}

export default App;
