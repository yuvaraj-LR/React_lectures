import React, { Component } from "react";

// Complete this Component
const ListItem = () => {
  return (
    <div
      className="ListItem"
      style={{
        height: 30
      }}
    >
      <img src="" alt="" />
      <a href=""></a>
    </div>
  );
};

export default ListItem;
