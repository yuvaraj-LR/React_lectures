import { Component } from "react";

// Complete the AnimeList Component
class AnimeList extends Component {
  render() {
    return <div className="anime-list">
      {/* Map the anime list recieved through props and pass the details to the Animecard component*/}
    </div>;
  }
}

export default AnimeList;
