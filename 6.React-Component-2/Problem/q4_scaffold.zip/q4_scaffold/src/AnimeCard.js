import { Component } from "react";

// Complete the AnimeCard Component
class AnimeCard extends Component {
  render() {
    return <div className="anime-card">
      <img src={} alt={} />
        <p>{}</p>
    </div>;
  }
}

export default AnimeCard;
