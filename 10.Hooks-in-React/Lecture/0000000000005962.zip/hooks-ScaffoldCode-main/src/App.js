import Input from "./Components/InputWithClass";

function App() {
  return (
    <>
      <Input />

     
    </>
  );
}

export default App;
