const useLocalStorage = (key, defaultValue) => {
  // Add the state and effect here
};

export default useLocalStorage;
