
// Complete the following hook
const useFetch = (url) => {
  const getJoke = async () => {
  };
  //It should return data returned from fetch, loading, error and getJoke
};
// export the useFetch hook as a default export
